package com.example.spotifylyrics.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.text.Text;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            LyricsConfig c = LyricsConfig.INSTANCE;
            ConfigBuilder b = ConfigBuilder.create()
                    .setParentScreen(parent)
                    .setTitle(Text.literal("Spotify Lyrics"))
                    .setSavingRunnable(LyricsConfig::save);
            ConfigEntryBuilder e = b.entryBuilder();

            ConfigCategory general = b.getOrCreateCategory(Text.literal("General"));
            general.addEntry(e.startBooleanToggle(Text.literal("Enabled"), c.enabled)
                    .setDefaultValue(true).setSaveConsumer(v -> c.enabled = v).build());
            general.addEntry(e.startBooleanToggle(Text.literal("Show lyrics"), c.showLyrics)
                    .setDefaultValue(true).setSaveConsumer(v -> c.showLyrics = v).build());
            general.addEntry(e.startBooleanToggle(Text.literal("Floating 3D lyrics (off = flat HUD lyrics)"), c.worldLyrics)
                    .setDefaultValue(true).setSaveConsumer(v -> c.worldLyrics = v).build());
            general.addEntry(e.startBooleanToggle(Text.literal("Show top HUD bar"), c.showHud)
                    .setDefaultValue(true).setSaveConsumer(v -> c.showHud = v).build());
            general.addEntry(e.startBooleanToggle(Text.literal("Show album cover"), c.showCover)
                    .setDefaultValue(true).setSaveConsumer(v -> c.showCover = v).build());
            general.addEntry(e.startBooleanToggle(Text.literal("Show visualizer"), c.showVisualizer)
                    .setDefaultValue(true).setSaveConsumer(v -> c.showVisualizer = v).build());

            ConfigCategory style = b.getOrCreateCategory(Text.literal("Style"));
            style.addEntry(e.startColorField(Text.literal("Main neon color"), c.color)
                    .setDefaultValue(0xFF2DD4).setSaveConsumer(v -> c.color = v & 0xFFFFFF).build());
            style.addEntry(e.startColorField(Text.literal("Glow / secondary color"), c.secondaryColor)
                    .setDefaultValue(0x9D4DFF).setSaveConsumer(v -> c.secondaryColor = v & 0xFFFFFF).build());
            style.addEntry(e.startIntSlider(Text.literal("Text size (%)"), c.textScalePercent, 50, 600)
                    .setDefaultValue(250).setSaveConsumer(v -> c.textScalePercent = v).build());
            style.addEntry(e.startIntSlider(Text.literal("Glow strength"), c.glowStrength, 0, 12)
                    .setDefaultValue(6).setSaveConsumer(v -> c.glowStrength = v).build());
            style.addEntry(e.startIntSlider(Text.literal("HUD lyrics vertical position (%)"), c.yOffsetPercent, 0, 100)
                    .setDefaultValue(40).setSaveConsumer(v -> c.yOffsetPercent = v).build());
            style.addEntry(e.startIntSlider(Text.literal("HUD bar Y offset"), c.hudYOffset, 0, 200)
                    .setDefaultValue(6).setSaveConsumer(v -> c.hudYOffset = v).build());

            ConfigCategory world = b.getOrCreateCategory(Text.literal("3D Lyrics"));
            world.addEntry(e.startIntSlider(Text.literal("Distance (blocks)"), c.worldDistance, 3, 24)
                    .setDefaultValue(8).setSaveConsumer(v -> c.worldDistance = v).build());
            world.addEntry(e.startIntSlider(Text.literal("Elevation (degrees above horizon)"), c.worldElevation, -30, 70)
                    .setDefaultValue(12).setSaveConsumer(v -> c.worldElevation = v).build());
            world.addEntry(e.startBooleanToggle(Text.literal("Slowly follow where I look"), c.worldFollow)
                    .setDefaultValue(true).setSaveConsumer(v -> c.worldFollow = v).build());

            ConfigCategory spotify = b.getOrCreateCategory(Text.literal("Spotify"));
            spotify.addEntry(e.startStrField(Text.literal("Spotify Client ID"), c.spotifyClientId)
                    .setTooltip(Text.literal("Create an app at developer.spotify.com, add redirect URI http://127.0.0.1:8888/callback, then run /lyrics login"))
                    .setSaveConsumer(v -> c.spotifyClientId = v.trim()).build());
            return b.build();
        };
    }
}
