package com.example.spotifylyrics.render;

import com.example.spotifylyrics.SpotifyLyricsClient;
import com.example.spotifylyrics.lyrics.LyricLine;
import com.example.spotifylyrics.spotify.PlaybackState;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/** What should be on screen right now. Shared by the HUD and the 3D renderer. */
public record LyricFrame(String prev, String cur, String next, float ease) {
    private static final long FADE_MS = 350;

    public static LyricFrame compute(PlaybackState s) {
        List<LyricLine> lines = SpotifyLyricsClient.lyrics;
        if (lines == null || lines.isEmpty()) return null;

        long pos = s.positionNow() + 150; // small lead so a line appears just before it is sung
        int idx = currentIndex(lines, pos);
        if (idx < 0) return null;

        LyricLine cur = lines.get(idx);
        float t = MathHelper.clamp((pos - cur.timeMs()) / (float) FADE_MS, 0f, 1f);
        float ease = 1f - (1f - t) * (1f - t) * (1f - t); // easeOutCubic

        return new LyricFrame(
                idx > 0 ? lines.get(idx - 1).text() : "",
                cur.text(),
                idx + 1 < lines.size() ? lines.get(idx + 1).text() : "",
                ease);
    }

    private static int currentIndex(List<LyricLine> l, long pos) {
        int lo = 0, hi = l.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (l.get(mid).timeMs() <= pos) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }

    // ---- color helpers (shared) ----
    /** Alpha is clamped to >= 4 because vanilla text treats very low alpha as opaque. */
    public static int argb(float alpha, int rgb) {
        int a = MathHelper.clamp((int) (alpha * 255), 4, 255);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
