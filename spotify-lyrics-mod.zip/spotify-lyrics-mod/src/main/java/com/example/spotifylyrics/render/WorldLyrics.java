package com.example.spotifylyrics.render;

import com.example.spotifylyrics.config.LyricsConfig;
import com.example.spotifylyrics.spotify.PlaybackState;
import com.example.spotifylyrics.spotify.SpotifyClient;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/**
 * Floating neon lyrics, drawn in the world at WorldRenderEvents.AFTER_ENTITIES.
 *
 * Since 1.21.9 vanilla no longer lets you draw text immediately in the world: you submit it to an
 * OrderedRenderCommandQueue and the renderer flushes it later. Fabric's world render context exposes
 * that queue (commandQueue()) and the matrix stack (matrices()), whose coordinates are camera-relative.
 * So the lyric panel's position is just "direction * distance" from the camera, no camera position needed.
 */
public class WorldLyrics {
    private static boolean anchored = false;
    private static float anchorYaw;

    /** /lyrics recenter: put the panel where you're looking right now. */
    public static void recenter() { anchored = false; }

    public static void render(WorldRenderContext ctx) {
        LyricsConfig cfg = LyricsConfig.INSTANCE;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.enabled || !cfg.showLyrics || !cfg.worldLyrics || mc.player == null) return;

        PlaybackState s = SpotifyClient.current;
        if (s == null) return;
        LyricFrame f = LyricFrame.compute(s);
        if (f == null) return;

        MatrixStack m = ctx.matrices();
        OrderedRenderCommandQueue queue = ctx.commandQueue();
        if (m == null || queue == null) return;

        Camera cam = mc.gameRenderer.getCamera();
        updateAnchor(cam.getYaw(), cfg);

        // Panel direction in world space (Minecraft: yaw 0 = +Z, positive pitch = looking down)
        double yaw = Math.toRadians(anchorYaw);
        double pitch = Math.toRadians(-cfg.worldElevation);
        double cosP = Math.cos(pitch);
        float dist = cfg.worldDistance;
        float dx = (float) (-Math.sin(yaw) * cosP) * dist;
        float dy = (float) (-Math.sin(pitch)) * dist;
        float dz = (float) (Math.cos(yaw) * cosP) * dist;

        // World units per font pixel. Scales with distance so apparent size stays constant.
        float scale = dist * 0.004f * (cfg.textScalePercent / 100f);

        m.push();
        m.translate(dx, dy, dz);
        m.multiply(cam.getRotation());          // billboard: face the camera
        m.scale(scale, -scale, scale);          // same flip vanilla name tags use

        TextRenderer tr = mc.textRenderer;
        float ease = f.ease();

        if (!f.prev().isEmpty())
            line(queue, m, tr, f.prev(), -16f * ease - 12f, 0.75f, 0.55f * (1f - ease), false, cfg);
        if (!f.cur().isEmpty()) {
            float bob = (float) Math.sin(System.currentTimeMillis() / 700.0) * 0.6f;
            line(queue, m, tr, f.cur(), (1f - ease) * 8f + bob, 1.0f, 0.35f + 0.65f * ease, true, cfg);
        }
        if (!f.next().isEmpty())
            line(queue, m, tr, f.next(), 16f, 0.75f, 0.3f, false, cfg);

        m.pop();
    }

    private static void line(OrderedRenderCommandQueue q, MatrixStack m, TextRenderer tr, String text,
                             float y, float sizeMul, float alpha, boolean glow, LyricsConfig cfg) {
        m.push();
        m.scale(sizeMul, sizeMul, sizeMul);
        float x = -tr.getWidth(text) / 2f;
        var ordered = Text.literal(text).asOrderedText();

        if (glow && cfg.glowStrength > 0) {
            int halo = LyricFrame.argb(alpha * 0.10f, cfg.secondaryColor);
            // 3 rings x 8 directions keeps the submit count reasonable (each submit is a draw command)
            int rings = Math.max(1, (cfg.glowStrength + 3) / 4);
            for (int r = rings; r >= 1; r--) {
                float rr = r * (cfg.glowStrength / (float) rings) * 0.35f;
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    m.push();
                    m.translate((float) Math.cos(a) * rr, (float) Math.sin(a) * rr, 0.4f * r); // push halo behind the core
                    submit(q, m, ordered, x, y, halo);
                    m.pop();
                }
            }
            int mid = LyricFrame.argb(alpha * 0.35f, cfg.color);
            m.push();
            m.translate(0f, 0f, 0.2f);
            submit(q, m, ordered, x - 0.8f, y, mid);
            submit(q, m, ordered, x + 0.8f, y, mid);
            m.pop();
        }
        int core = LyricFrame.argb(alpha, LyricFrame.blend(cfg.color, 0xFFFFFF, glow ? 0.55f : 0.15f));
        submit(q, m, ordered, x, y, core);
        m.pop();
    }

    private static void submit(OrderedRenderCommandQueue q, MatrixStack m,
                               net.minecraft.text.OrderedText text, float x, float y, int argb) {
        // (matrices, x, y, text, dropShadow, layerType, light, color, backgroundColor, outlineColor)
        q.submitText(m, x, y, text, false, TextRenderer.TextLayerType.NORMAL,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, argb, 0, 0);
    }

    /** Panel stays put while you look around; if you turn far away it glides after you. */
    private static void updateAnchor(float playerYaw, LyricsConfig cfg) {
        if (!anchored) { anchorYaw = playerYaw; anchored = true; return; }
        if (!cfg.worldFollow) return;
        float diff = MathHelper.wrapDegrees(playerYaw - anchorYaw);
        float dead = 35f; // degrees you may turn before the panel starts following
        if (Math.abs(diff) > dead) anchorYaw += (diff - Math.signum(diff) * dead) * 0.08f;
    }
}
