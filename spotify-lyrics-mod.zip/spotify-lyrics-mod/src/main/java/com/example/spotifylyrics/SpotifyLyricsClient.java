package com.example.spotifylyrics;

import com.example.spotifylyrics.config.LyricsConfig;
import com.example.spotifylyrics.lyrics.LrcLibClient;
import com.example.spotifylyrics.lyrics.LyricLine;
import com.example.spotifylyrics.render.CoverManager;
import com.example.spotifylyrics.render.LyricsHud;
import com.example.spotifylyrics.render.WorldLyrics;
import com.example.spotifylyrics.spotify.SpotifyAuth;
import com.example.spotifylyrics.spotify.SpotifyClient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class SpotifyLyricsClient implements ClientModInitializer {
    public static volatile List<LyricLine> lyrics = List.of();

    @Override
    public void onInitializeClient() {
        LyricsConfig.load();

        // HUD bar (and flat lyrics when 3D mode is off), drawn just before the chat layer
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("spotifylyrics", "hud"), LyricsHud::render);

        // Floating 3D lyrics
        WorldRenderEvents.AFTER_ENTITIES.register(WorldLyrics::render);

        SpotifyClient.start(state -> {
            lyrics = List.of(); // clear while the new track's lyrics load
            CoverManager.load(state.coverUrl());
            Thread t = new Thread(() -> lyrics = LrcLibClient.fetch(state), "SpotifyLyrics-Fetch");
            t.setDaemon(true);
            t.start();
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) ->
            dispatcher.register(ClientCommandManager.literal("lyrics")
                .then(ClientCommandManager.literal("login").executes(ctx -> {
                    if (LyricsConfig.INSTANCE.spotifyClientId.isBlank()) {
                        ctx.getSource().sendFeedback(Text.literal("Set your Spotify Client ID first: Mod Menu > Spotify Lyrics > Spotify."));
                        return 0;
                    }
                    ctx.getSource().sendFeedback(Text.literal("Opening browser for Spotify login..."));
                    SpotifyAuth.login().thenAccept(ok -> MinecraftClient.getInstance().execute(() ->
                        ctx.getSource().sendFeedback(Text.literal(ok ? "Spotify linked!" : "Spotify login failed."))));
                    return 1;
                }))
                .then(ClientCommandManager.literal("logout").executes(ctx -> {
                    SpotifyAuth.logout();
                    ctx.getSource().sendFeedback(Text.literal("Logged out of Spotify."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    LyricsConfig.INSTANCE.enabled = !LyricsConfig.INSTANCE.enabled;
                    LyricsConfig.save();
                    ctx.getSource().sendFeedback(Text.literal("Lyrics " + (LyricsConfig.INSTANCE.enabled ? "on" : "off")));
                    return 1;
                }))
                .then(ClientCommandManager.literal("recenter").executes(ctx -> {
                    WorldLyrics.recenter();
                    ctx.getSource().sendFeedback(Text.literal("Lyrics moved to where you're looking."));
                    return 1;
                }))));
    }
}
