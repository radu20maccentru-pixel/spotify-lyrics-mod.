package com.example.spotifylyrics.render;

import com.example.spotifylyrics.config.LyricsConfig;
import com.example.spotifylyrics.spotify.PlaybackState;
import com.example.spotifylyrics.spotify.SpotifyClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix3x2fStack;

/** Registered as a HudElement (see SpotifyLyricsClient). */
public class LyricsHud {

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        LyricsConfig cfg = LyricsConfig.INSTANCE;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.enabled || mc.options.hudHidden || mc.player == null) return;

        PlaybackState s = SpotifyClient.current;
        if (s == null) return;

        if (cfg.showHud) drawBar(ctx, mc.textRenderer, s, cfg);
        if (cfg.showLyrics && !cfg.worldLyrics) drawFlatLyrics(ctx, mc.textRenderer, s, cfg);
    }

    // ---------------- TOP BAR ----------------
    private static void drawBar(DrawContext ctx, TextRenderer tr, PlaybackState s, LyricsConfig cfg) {
        int sw = ctx.getScaledWindowWidth();
        int w = 190, h = 38;
        int x = (sw - w) / 2, y = cfg.hudYOffset;

        ctx.fill(x, y, x + w, y + h, 0xAA000000);
        ctx.fill(x, y, x + w, y + 1, 0xFF000000 | cfg.color);               // neon top edge
        ctx.fill(x, y + h - 1, x + w, y + h, 0xFF000000 | cfg.secondaryColor);

        int textX = x + 6;
        if (cfg.showCover && CoverManager.ready()) {
            // 1.21.6+: drawTexture takes a RenderPipeline (not a RenderLayer function)
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, CoverManager.id(),
                    x + 5, y + 5, 0f, 0f, 28, 28, 64, 64, 64, 64);
            textX = x + 38;
        }
        int maxW = x + w - 6 - textX - (cfg.showVisualizer ? 22 : 0);
        ctx.drawText(tr, trim(tr, s.title(), maxW), textX, y + 6, 0xFFFFFFFF, true);
        ctx.drawText(tr, trim(tr, s.artist(), maxW), textX, y + 17, 0xFFAAAAAA, false);

        // progress bar
        int px = textX, pw = x + w - 6 - textX, py = y + h - 7;
        ctx.fill(px, py, px + pw, py + 2, 0x55FFFFFF);
        int filled = (int) (pw * (s.positionNow() / (double) Math.max(1, s.durationMs())));
        ctx.fill(px, py, px + filled, py + 2, 0xFF000000 | cfg.color);

        // Pseudo-visualizer: animated bars, NOT real audio analysis (Spotify's stream isn't accessible to the game).
        if (cfg.showVisualizer) {
            double t = System.currentTimeMillis() / 1000.0;
            for (int i = 0; i < 4; i++) {
                int bh = s.playing() ? 3 + (int) ((Math.sin(t * (4 + i * 1.7) + i) * 0.5 + 0.5) * 14) : 2;
                int bx = x + w - 20 + i * 4;
                ctx.fill(bx, y + 22 - bh, bx + 3, y + 22, 0xFF000000 | (i % 2 == 0 ? cfg.color : cfg.secondaryColor));
            }
        }
    }

    // ---------------- FLAT HUD LYRICS (used when 3D lyrics are off) ----------------
    private static void drawFlatLyrics(DrawContext ctx, TextRenderer tr, PlaybackState s, LyricsConfig cfg) {
        LyricFrame f = LyricFrame.compute(s);
        if (f == null) return;

        float scale = cfg.textScalePercent / 100f;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float baseY = sh * (cfg.yOffsetPercent / 100f);
        float ease = f.ease();

        if (!f.prev().isEmpty())
            drawNeon(ctx, tr, f.prev(), sw / 2f, baseY - 14 * scale * ease, scale * 0.75f, 0.55f * (1f - ease), false, cfg);
        if (!f.cur().isEmpty()) {
            float bob = (float) Math.sin(System.currentTimeMillis() / 700.0) * 1.5f;
            drawNeon(ctx, tr, f.cur(), sw / 2f, baseY + (1f - ease) * 8 * scale + bob, scale, 0.35f + 0.65f * ease, true, cfg);
        }
        if (!f.next().isEmpty())
            drawNeon(ctx, tr, f.next(), sw / 2f, baseY + 16 * scale, scale * 0.75f, 0.3f, false, cfg);
    }

    /** Fake neon: halo = same text at several offsets with low alpha, core = bright text on top. */
    private static void drawNeon(DrawContext ctx, TextRenderer tr, String text, float cx, float y,
                                 float scale, float alpha, boolean glow, LyricsConfig cfg) {
        // 1.21.6+: DrawContext matrices are 2D (Matrix3x2fStack): pushMatrix/popMatrix, translate(x,y), scale(x,y)
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, y);
        m.scale(scale, scale);
        int x = -tr.getWidth(text) / 2;

        if (glow && cfg.glowStrength > 0) {
            int halo = LyricFrame.argb(alpha * 0.10f, cfg.secondaryColor);
            for (int r = cfg.glowStrength; r >= 1; r--) {
                float rr = r * 0.35f;
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    m.pushMatrix();
                    m.translate((float) Math.cos(a) * rr, (float) Math.sin(a) * rr);
                    ctx.drawText(tr, text, x, 0, halo, false);
                    m.popMatrix();
                }
            }
            int mid = LyricFrame.argb(alpha * 0.35f, cfg.color);
            ctx.drawText(tr, text, x - 1, 0, mid, false);
            ctx.drawText(tr, text, x + 1, 0, mid, false);
        }
        int core = LyricFrame.argb(alpha, LyricFrame.blend(cfg.color, 0xFFFFFF, glow ? 0.55f : 0.15f));
        ctx.drawText(tr, text, x, 0, core, false);
        m.popMatrix();
    }

    private static String trim(TextRenderer tr, String s, int maxW) {
        return tr.getWidth(s) <= maxW ? s : tr.trimToWidth(s, maxW - tr.getWidth("...")) + "...";
    }
}
