package com.example.spotifylyrics.spotify;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** Polls /me/player/currently-playing every few seconds on a background thread. */
public class SpotifyClient {
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final ScheduledExecutorService EXEC = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "SpotifyLyrics-Poll"); t.setDaemon(true); return t;
    });

    public static volatile PlaybackState current = null;
    private static volatile long backoffUntil = 0;

    public static void start(Consumer<PlaybackState> onTrackChange) {
        EXEC.scheduleWithFixedDelay(() -> {
            try {
                if (System.currentTimeMillis() < backoffUntil) return;
                String token = SpotifyAuth.token();
                if (token == null) { current = null; return; }

                HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing"))
                        .header("Authorization", "Bearer " + token).GET().build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());

                if (res.statusCode() == 429) {
                    long wait = res.headers().firstValue("Retry-After").map(Long::parseLong).orElse(10L);
                    backoffUntil = System.currentTimeMillis() + wait * 1000; return;
                }
                if (res.statusCode() != 200) { current = null; return; } // 204 = nothing playing

                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                JsonElement itemEl = o.get("item");
                if (itemEl == null || itemEl.isJsonNull()) { current = null; return; }
                JsonObject item = itemEl.getAsJsonObject();

                StringBuilder artists = new StringBuilder();
                for (JsonElement a : item.getAsJsonArray("artists")) {
                    if (artists.length() > 0) artists.append(", ");
                    artists.append(a.getAsJsonObject().get("name").getAsString());
                }
                JsonObject album = item.getAsJsonObject("album");
                JsonArray imgs = album.getAsJsonArray("images");
                String cover = imgs.size() > 0
                        ? imgs.get(imgs.size() > 1 ? 1 : 0).getAsJsonObject().get("url").getAsString() : null;

                PlaybackState prev = current;
                PlaybackState next = new PlaybackState(
                        item.get("id").isJsonNull() ? item.get("name").getAsString() : item.get("id").getAsString(),
                        item.get("name").getAsString(), artists.toString(),
                        album.get("name").getAsString(), cover,
                        item.get("duration_ms").getAsLong(), o.get("progress_ms").getAsLong(),
                        o.get("is_playing").getAsBoolean(), System.currentTimeMillis());
                current = next;
                if (prev == null || !prev.trackId().equals(next.trackId())) onTrackChange.accept(next);
            } catch (Exception e) { /* network hiccup: keep last state */ }
        }, 0, 3, TimeUnit.SECONDS);
    }
}
