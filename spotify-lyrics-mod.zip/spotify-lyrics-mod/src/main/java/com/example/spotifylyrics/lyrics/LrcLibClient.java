package com.example.spotifylyrics.lyrics;

import com.example.spotifylyrics.spotify.PlaybackState;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** https://lrclib.net: free, no key, returns LRC text in "syncedLyrics". */
public class LrcLibClient {
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static List<LyricLine> fetch(PlaybackState s) {
        try {
            String artist = s.artist().split(",")[0].trim();
            String url = "https://lrclib.net/api/get"
                    + "?track_name=" + enc(s.title())
                    + "&artist_name=" + enc(artist)
                    + "&album_name=" + enc(s.album())
                    + "&duration=" + (s.durationMs() / 1000);
            HttpResponse<String> r = send(url);
            if (r.statusCode() == 404) { // fall back to fuzzy search
                r = send("https://lrclib.net/api/search?q=" + enc(s.title() + " " + artist));
                if (r.statusCode() != 200) return List.of();
                for (JsonElement el : JsonParser.parseString(r.body()).getAsJsonArray()) {
                    List<LyricLine> l = fromJson(el.getAsJsonObject());
                    if (!l.isEmpty()) return l;
                }
                return List.of();
            }
            if (r.statusCode() != 200) return List.of();
            return fromJson(JsonParser.parseString(r.body()).getAsJsonObject());
        } catch (Exception e) { return List.of(); }
    }

    private static List<LyricLine> fromJson(JsonObject o) {
        JsonElement synced = o.get("syncedLyrics");
        if (synced == null || synced.isJsonNull()) return List.of();
        return LrcParser.parse(synced.getAsString());
    }

    private static HttpResponse<String> send(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "SpotifyLyricsFabricMod/1.0").GET().build();
        return HTTP.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
