package com.example.spotifylyrics.lyrics;

public record LyricLine(long timeMs, String text) {}
