package com.example.spotifylyrics.lyrics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LrcParser {
    private static final Pattern TAG = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    public static List<LyricLine> parse(String lrc) {
        List<LyricLine> out = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = TAG.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                long min = Long.parseLong(m.group(1)), sec = Long.parseLong(m.group(2));
                long ms = 0;
                if (m.group(3) != null) {
                    String f = m.group(3);
                    ms = Long.parseLong(f) * (f.length() == 1 ? 100 : f.length() == 2 ? 10 : 1);
                }
                times.add(min * 60_000 + sec * 1000 + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long t : times) out.add(new LyricLine(t, text));
        }
        out.sort(Comparator.comparingLong(LyricLine::timeMs));
        return out;
    }
}
