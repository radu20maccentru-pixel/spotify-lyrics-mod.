package com.example.spotifylyrics.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.URI;

/** Downloads the album art (JPEG) and uploads it as a GUI texture. */
public class CoverManager {
    private static final Identifier ID = Identifier.of("spotifylyrics", "cover");
    private static final int SIZE = 64;
    private static volatile boolean ready = false;
    private static NativeImageBackedTexture tex;

    public static boolean ready() { return ready; }
    public static Identifier id() { return ID; }

    public static void load(String url) {
        ready = false;
        if (url == null) return;
        Thread t = new Thread(() -> {
            try (var in = URI.create(url).toURL().openStream()) {
                BufferedImage src = ImageIO.read(in); // ImageIO decodes JPEG; NativeImage.read does not
                Image scaled = src.getScaledInstance(SIZE, SIZE, Image.SCALE_SMOOTH);
                BufferedImage bi = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
                bi.getGraphics().drawImage(scaled, 0, 0, null);

                NativeImage img = new NativeImage(NativeImage.Format.RGBA, SIZE, SIZE, false);
                for (int y = 0; y < SIZE; y++)
                    for (int x = 0; x < SIZE; x++)
                        img.setColorArgb(x, y, bi.getRGB(x, y));

                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> {
                    if (tex != null) mc.getTextureManager().destroyTexture(ID);
                    // 1.21.5+ textures carry a debug name. If your mappings expect a plain String
                    // instead of a Supplier, change the lambda to "spotifylyrics_cover".
                    tex = new NativeImageBackedTexture(() -> "spotifylyrics_cover", img);
                    mc.getTextureManager().registerTexture(ID, tex);
                    ready = true;
                });
            } catch (Exception e) { e.printStackTrace(); }
        }, "SpotifyLyrics-Cover");
        t.setDaemon(true);
        t.start();
    }
}
