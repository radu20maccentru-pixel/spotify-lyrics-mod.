package com.example.spotifylyrics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Plain JSON config. Edited in-game through Cloth Config (see ModMenuIntegration). */
public class LyricsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("spotifylyrics.json");
    public static LyricsConfig INSTANCE = new LyricsConfig();

    // --- general ---
    public boolean enabled = true;
    public boolean showHud = true;          // top bar
    public boolean showCover = true;
    public boolean showVisualizer = true;
    public boolean showLyrics = true;       // master switch for lyric text (HUD or world)
    public boolean worldLyrics = true;      // true = floating 3D lyrics, false = flat HUD lyrics

    // --- style ---
    public int color = 0xFF2DD4;            // neon pink (RGB)
    public int secondaryColor = 0x9D4DFF;   // neon purple (glow halo)
    public int textScalePercent = 250;      // 100 = vanilla size (HUD) / smaller in world, see WorldLyrics
    public int yOffsetPercent = 40;         // HUD lyrics: 0 = top, 100 = bottom
    public int glowStrength = 6;            // 0 disables glow
    public int hudYOffset = 6;

    // --- world lyrics ---
    public int worldDistance = 8;           // blocks in front of you
    public int worldElevation = 12;         // degrees above the horizon
    public boolean worldFollow = true;      // slowly turn with you instead of staying fixed

    // --- Spotify auth ---
    public String spotifyClientId = "";
    public String accessToken = "";
    public String refreshToken = "";
    public long expiresAtMs = 0;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                LyricsConfig c = GSON.fromJson(Files.readString(FILE), LyricsConfig.class);
                if (c != null) INSTANCE = c;
            } else save();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static synchronized void save() {
        try { Files.writeString(FILE, GSON.toJson(INSTANCE)); }
        catch (Exception e) { e.printStackTrace(); }
    }
}
