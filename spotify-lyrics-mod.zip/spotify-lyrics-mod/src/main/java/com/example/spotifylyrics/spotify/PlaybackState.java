package com.example.spotifylyrics.spotify;

/** Snapshot from one API poll. Position is interpolated locally between polls. */
public record PlaybackState(String trackId, String title, String artist, String album,
                            String coverUrl, long durationMs, long progressMs,
                            boolean playing, long fetchedAtMs) {

    public long positionNow() {
        if (!playing) return progressMs;
        long p = progressMs + (System.currentTimeMillis() - fetchedAtMs);
        return Math.min(p, durationMs);
    }
}
