package com.example.spotifylyrics.spotify;

import com.example.spotifylyrics.config.LyricsConfig;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import net.minecraft.util.Util;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.StringJoiner;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/** Authorization Code + PKCE flow (no client secret needed). */
public class SpotifyAuth {
    private static final String REDIRECT = "http://127.0.0.1:8888/callback";
    private static final String SCOPE = "user-read-currently-playing user-read-playback-state";
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    /** Opens the browser, waits for the callback, stores tokens. */
    public static CompletableFuture<Boolean> login() {
        return CompletableFuture.supplyAsync(() -> {
            LyricsConfig c = LyricsConfig.INSTANCE;
            if (c.spotifyClientId.isBlank()) return false;
            try {
                byte[] raw = new byte[64];
                new SecureRandom().nextBytes(raw);
                String verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
                String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(
                        MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));

                CompletableFuture<String> codeFuture = new CompletableFuture<>();
                HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 8888), 0);
                server.createContext("/callback", ex -> {
                    String q = ex.getRequestURI().getQuery();
                    String code = null;
                    if (q != null) for (String kv : q.split("&"))
                        if (kv.startsWith("code=")) code = kv.substring(5);
                    byte[] body = "<html><body style='font-family:sans-serif'><h2>Spotify linked. You can close this tab and return to Minecraft.</h2></body></html>"
                            .getBytes(StandardCharsets.UTF_8);
                    ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
                    ex.sendResponseHeaders(200, body.length);
                    ex.getResponseBody().write(body);
                    ex.close();
                    if (code != null) codeFuture.complete(code);
                    else codeFuture.completeExceptionally(new RuntimeException("no code"));
                });
                server.start();

                String url = "https://accounts.spotify.com/authorize?response_type=code"
                        + "&client_id=" + enc(c.spotifyClientId)
                        + "&scope=" + enc(SCOPE)
                        + "&redirect_uri=" + enc(REDIRECT)
                        + "&code_challenge_method=S256&code_challenge=" + challenge;
                Util.getOperatingSystem().open(URI.create(url));

                String code;
                try { code = codeFuture.get(3, TimeUnit.MINUTES); }
                finally { server.stop(0); }

                return tokenRequest(Map.of(
                        "grant_type", "authorization_code",
                        "code", code,
                        "redirect_uri", REDIRECT,
                        "client_id", c.spotifyClientId,
                        "code_verifier", verifier));
            } catch (Exception e) { e.printStackTrace(); return false; }
        });
    }

    /** Returns a valid access token, refreshing if needed. Null if not logged in. */
    public static synchronized String token() {
        LyricsConfig c = LyricsConfig.INSTANCE;
        if (c.refreshToken.isBlank()) return null;
        if (System.currentTimeMillis() > c.expiresAtMs - 30_000) {
            try {
                tokenRequest(Map.of("grant_type", "refresh_token",
                        "refresh_token", c.refreshToken, "client_id", c.spotifyClientId));
            } catch (Exception e) { e.printStackTrace(); return null; }
        }
        return c.accessToken.isBlank() ? null : c.accessToken;
    }

    public static void logout() {
        LyricsConfig c = LyricsConfig.INSTANCE;
        c.accessToken = ""; c.refreshToken = ""; c.expiresAtMs = 0;
        LyricsConfig.save();
    }

    private static boolean tokenRequest(Map<String, String> form) throws Exception {
        StringJoiner sj = new StringJoiner("&");
        form.forEach((k, v) -> sj.add(k + "=" + enc(v)));
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(sj.toString())).build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) return false;
        JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
        LyricsConfig c = LyricsConfig.INSTANCE;
        c.accessToken = o.get("access_token").getAsString();
        if (o.has("refresh_token")) c.refreshToken = o.get("refresh_token").getAsString();
        c.expiresAtMs = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000;
        LyricsConfig.save();
        return true;
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
